<?php
//database connection parameters
define ("SERVERNAME", "localhost");
define ("USERNAME","root");
define ("PASSWORD","");
define ("DBNAME","shoppn");
?>