<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8"/>
    <title>SignUp</title>
    <link rel="stylesheet" href="css/style_c.css"/>
</head>
<body>

    <form class="form" action="" method="post">
        <h1 class="login-title">Registration</h1>
        <input type="text" class="login-input" name="customer_name" placeholder="Name" required />
        <input type="text" class="login-input" name="customer_email" placeholder="Email Adress">
        <input type="password" class="login-input" name="customer_pass" placeholder="Password">
        <input type="text" class="login-input" name="customer_country" placeholder="Country">
        <input type="text" class="login-input" name="customer_city" placeholder="City">
        <input type="text" class="login-input" name="customer_contact" placeholder="Contacts">

        <input type="submit" name="submit" value="Register" class="register-button">

        <p class="link">Already have an account? <a href="login.php">Login here</a></p>
    </form>

</body>
</html>
