<?php
require("../settings/db_class.php");


//Registering the user

class Customer extends db_connection {
    function addCustomer_cls($customer_name, $customer_email, $customer_pass, $customer_country, $customer_city, $user_role){

        //write the sql
        $sqltwo = "INSERT INTO customer (`customer_id`, `customer_name`, `customer_email`,`customer_pass`, `customer_country`, `customer_city`, `customer_contact`, `user_role`)
        VALUES([`customer_id`],[`customer_name`],[`customer_email`],[`customer_pass`],[`customer_country`],[`customer_city`],[`customer_contact`],[`user_role`])";
        
     //execute the sql
        return $this->db_query($sqltwo)

    //select as well
    function verify($customer_email){
		$sqltwo= "SELECT * FROM customer WHERE '$customer_email'='customer_email'";
		return $this->db_fetch_one($sqltwo);
	}
    

    //Logging In the User 
    
	public function Customerlogin_cls($customer_email, $customer_pass){
		$sql = "SELECT `customer_id`,`user_role` FROM `customer` WHERE `customer_email` = '$customer_email'";
		return $this->db_fetch_one($sqltwo);
	}

?>