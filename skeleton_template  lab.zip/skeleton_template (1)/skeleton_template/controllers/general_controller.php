<?php
//connect to the user account class
include("../classes/general_class.php");

//sanitize data




//--INSERT--//

//--SELECT--//

//--UPDATE--//

//--DELETE--//

?>