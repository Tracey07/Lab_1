<?php

//make the controller aware of the existence of the class
require('../classes/customer_class.php');

//edit,select,update,delete function

function addCustomer_ctr(){
    //create an instance of the class
    $add_class = new CustomerClass();

    // And then you run the methods of the class
    // return $add_class -> regCustomer_cls($placeholder_a, $placeholder_b)

    return $add_class -> regCustomer_cls( $customer_name, $customer_email, $customer_pass, $customer_country, $customer_city, $user_role);

   

    //logging In
}
?>