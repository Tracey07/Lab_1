<?php
// landing/index page
include("../controllers/customer_controller.php");

if (isset($_POST['submit'])) {

  $customer_name = $_POST['customer_name'];
  $customer_email = $_POST['customer_email'];
  $customer_pass = $_POST['customer_pass'];
  $customer_country = $_POST['customer_country'];
  $customer_city = $_POST['customer_city'];
  $customer_contact = $_POST['customer_contact'];
  
  
  if ($register) {
    echo "Registration Successful.";
    // now redirects to the login page
    header("Location: ../view/login.php");
} 
else{
    echo "Sorry! Registration unsuccessful";
    header("Location: ../view/register.php?error=registerFailed");
  }
}

