<?php

include("../controllers/customer_controller.php");

if (isset($_POST['submit'])) {
    $cutomer_email = $_POST['customer_email'];
    $customer_pass = $_POST['customer_pass'];


    $check = login_ctrl($customer_email, $customer_pass);

    //method for checking the email and password to retrieve the information for the to user logins
    if ($check) {
        print_r($check);

        //set session for customer_id and user role
        // session_start();
        $_SESSION['customerid'] = $check['customer_id'];
        $_SESSION['userrole'] = $check['user_role'];


    
        header("Location: ../index.php");

    } else {
        header("Location: ../view/login.php?error=loginfailed");
        echo "Log in failed,Kindly check your password again";
    }
}
